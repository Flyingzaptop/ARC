// Generated from captured provenance; scalar IEEE float32 class only.
ByteAddressBuffer Inputs : register(t0);
RWByteAddressBuffer Outputs : register(u0);
cbuffer Parameters : register(b0) { uint Count; };
[numthreads(64,1,1)]
void main(uint3 id : SV_DispatchThreadID) {
  uint i = id.x; if (i >= Count) return;
  precise float v0 = asfloat(Inputs.Load((i * 7 + 0) * 4));
  precise float v1 = asfloat(Inputs.Load((i * 7 + 1) * 4));
  precise float v2 = asfloat(Inputs.Load((i * 7 + 2) * 4));
  precise float v3 = asfloat(Inputs.Load((i * 7 + 3) * 4));
  precise float v4 = asfloat(Inputs.Load((i * 7 + 4) * 4));
  precise float v5 = asfloat(Inputs.Load((i * 7 + 5) * 4));
  precise float v6 = asfloat(Inputs.Load((i * 7 + 6) * 4));
  precise float t0 = v0 + v1;
  precise float t1 = t0 * v2;
  precise float t2 = v3 + v4;
  precise float t3 = t2 * v2;
  precise float t4 = v5 + v6;
  precise float t5 = t4 * v2;
  Outputs.Store((i * 3 + 0) * 4, asuint(t1));
  Outputs.Store((i * 3 + 1) * 4, asuint(t3));
  Outputs.Store((i * 3 + 2) * 4, asuint(t5));
}
